require 'test_helper'

class PublicationsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
