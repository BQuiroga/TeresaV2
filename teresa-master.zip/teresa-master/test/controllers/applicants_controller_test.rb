require 'test_helper'

class ApplicantsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
