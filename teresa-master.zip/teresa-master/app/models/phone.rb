class Phone < ActiveRecord::Base
  belongs_to :resume
end
