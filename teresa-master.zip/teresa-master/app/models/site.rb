class Site < ActiveRecord::Base
  belongs_to :resume
end
