class Email < ActiveRecord::Base
  belongs_to :resume
end
