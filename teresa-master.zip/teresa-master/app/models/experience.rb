class Experience < ActiveRecord::Base
  belongs_to :resume
end
