module ApplicantsHelper

end
